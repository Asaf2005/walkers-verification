memelist = {\
'memelist' : [
    "https://i.pinimg.com/originals/d6/a2/04/d6a2040fff1dfeb9824002688e8f8ae9.jpg",
    "https://i.imgflip.com/23rmha.jpg",
    "https://i.imgflip.com/48dvm5.jpg",
    "https://memegenerator.net/img/instances/76272544.jpg",
    "https://www.instagram.com/p/Buoi1QNFwj2/media?size=l",
    "https://www.instagram.com/p/Bt_wFUIFrq1/media?size=l",
    "https://www.instagram.com/p/Bsv3dVzFKwL/media?size=l",
    "https://www.instagram.com/p/B84dR0flT-L/media?size=l",
    "https://www.instagram.com/p/B4Rbo8bF1gD/media?size=l",
    "https://tenor.com/view/we-have-to-unite-and-be-strong-together-alan-walker-we-have-to-be-one-we-have-to-join-forces-we-have-to-come-together-gif-18264786",
    "https://tenor.com/view/nobody-sees-me-im-invisible-no-one-can-see-me-no-one-sees-me-heading-home-gif-16985017",
    "https://tenor.com/view/touch-press-press-it-hit-it-hit-the-switch-gif-16834183",
    "https://www.instagram.com/p/B_0WcscDb44/media?size=l",
    "https://www.instagram.com/p/B_h_2dGjMTt/media?size=l",
    "https://www.instagram.com/p/B_0WTIkjZvy/media?size=l",
    "https://media1.tenor.com/images/7a00f0e58dc8c5da8d6da09e2de20b2c/tenor.gif?itemid=17530559",
],\

}


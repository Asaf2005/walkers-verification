configs = {\
'prefix' : '$',\
'token' : 'Token here',\
'link' : 'https://(DOMAIN NAME HERE)/wp-login.php?redirect_to=(POST LINK HERE)',\
'verifiedrolename' : 'Walker',\
'unverifiedrolename': 'Unverified',\
'controlchannelname' : 'name here',\
'controlroomID' : 'ID here',\
'WelcomeChannel' : 'ID here',\
'email' : "Your email for the account on the platform",\
'password' : "Your password for the account on the platform",\
'commenturl' : "URL of the post",\
'Invitelink' : 'Invite link for the bot',\
'verificationchannelname' : 'verification',\
'logchannelname' : 'verification-bot-log',\
'generalchannelname' : 'general',\
'url' : 'URL to the wordpress API link to comments for accessing comments',\
'allposts' : 'URL to all posts section of the site',\
}
